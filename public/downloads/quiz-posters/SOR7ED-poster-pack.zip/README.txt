SOR7ED quiz poster pack

Five A4 vector PDFs plus high-resolution PNGs, using the original SOR7ED logo. QR codes encode their matching website URL and are scan-tested.

Hidden Strength Test is another address for Hidden Strength, not a separate assessment. Self-Perception Gap and Money Reset store answers only in browser storage and have Clear controls; Brain Type and Hidden Strength keep answers only in page memory. None are diagnostic tests.

Editable generator: create_posters.py. Requires reportlab, pymupdf and Pillow. Open-license Anton/Roboto fonts and their licences are included.
