from pathlib import Path
import json,sys,zipfile
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,black,white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF
from reportlab.lib.utils import ImageReader
import fitz
from PIL import Image
ROOT=Path(__file__).parent

pdfmetrics.registerFont(TTFont('Anton',str(ROOT/'assets/fonts/Anton-Regular.ttf')))
pdfmetrics.registerFont(TTFont('Roboto',str(ROOT/'assets/fonts/Roboto-Regular.ttf')))
W,H=595.276,841.89
YELLOW=HexColor('#FFD400');BG=HexColor('#000000');M=48
items=[
 ('brain-type',"WHAT'S YOUR",'BRAIN TYPE?',True),
 ('self-perception-gap','CAN YOU','PREDICT YOURSELF?',True),
 ('hidden-strength',"WHAT'S YOUR",'HIDDEN STRENGTH?',True),
 ('hidden-strength-test','WHICH TASK','SURPRISES YOU?',True),
 ('adhd-money-reset',"LET'S RESET",'YOUR MONEY.',True),
]
copy={
 'brain-type':['2 minutes. Free.','Nothing saved.'],
 'self-perception-gap':['6 rounds. Free.','Saved only','on this device.'],
 'hidden-strength':['5 challenges.','Free. Nothing saved.'],
 'hidden-strength-test':['5 challenges.','Free. Nothing saved.'],
 'adhd-money-reset':['Free. No sign-up.','Saved only','on this device.'],
}

def text(c,x,y,value,font,size,color,maxwidth=None):
 if maxwidth:size=min(size,maxwidth/pdfmetrics.stringWidth(value,font,1))
 c.setFillColor(color);c.setFont(font,size);c.drawString(x,y,value)

def poster(c,slug,top,bottom,live):
 c.setFillColor(BG);c.rect(0,0,W,H,fill=1,stroke=0)
 logo=ROOT/'assets/logo-white.png'
 c.drawImage(ImageReader(str(logo)),M,744,width=205,height=48,mask='auto',preserveAspectRatio=True)
 if not live:text(c,M,710,'DESIGN DRAFT — QUIZ NOT PUBLISHED', 'Roboto',11,YELLOW)
 text(c,M,599,top,'Anton',76,white,W-2*M)
 text(c,M,517,bottom,'Anton',76,YELLOW,W-2*M)
 x,y,size=M,173,280
 if live:
  c.setFillColor(white);c.rect(x,y,size,size,fill=1,stroke=0)
  widget=QrCodeWidget('https://www.planetsorted.com/'+slug,barLevel='M',barBorder=4)
  a,b,xx,yy=widget.getBounds();scale=(size-12)/(xx-a)
  drawing=Drawing(size-12,size-12,transform=[scale,0,0,scale,-a*scale,-b*scale]);drawing.add(widget)
  renderPDF.draw(drawing,c,x+6,y+6)
 else:
  c.setStrokeColor(YELLOW);c.setLineWidth(1);c.rect(x,y,size,size,fill=0,stroke=1)
  text(c,x+25,y+150,'QR CODE', 'Anton',36,white,size-50)
  text(c,x+25,y+115,'ADDED WHEN LIVE', 'Anton',22,YELLOW,size-50)
  text(c,x+25,y+70,'Awaiting the original quiz files.', 'Roboto',12,white,size-50)
 sx=x+size+26
 text(c,sx,337,'SCAN ME' if live else 'COMING SOON','Anton',31,YELLOW,W-sx-M)
 lines=copy[slug]
 for i,line in enumerate(lines):text(c,sx,300-i*25,line,'Roboto',17,white,W-sx-M)
 c.setStrokeColor(YELLOW);c.setLineWidth(2);c.line(M,93,W-M,93)
 text(c,M,58,'planetsorted.com/'+slug,'Roboto',19,white,W-2*M)
 if not live:text(c,M,32,'PROPOSED ADDRESS · NOT LIVE · DO NOT PRINT', 'Roboto',10,YELLOW)
 c.linkURL('https://www.planetsorted.com/'+slug,(M,45,W-M,80),relative=0) if live else None
 c.showPage()

combined=canvas.Canvas(str(ROOT/'SOR7ED-quiz-posters.pdf'),pagesize=(W,H));combined.setTitle('SOR7ED quiz posters')
manifest=[]
for item in items:
 slug,top,bottom,live=item
 c=canvas.Canvas(str(ROOT/(slug+('-poster' if live else '-DRAFT')+'.pdf')),pagesize=(W,H));c.setTitle('SOR7ED '+slug+(' poster' if live else ' design draft'));poster(c,*item);c.save();poster(combined,*item)
 doc=fitz.open(ROOT/(slug+('-poster' if live else '-DRAFT')+'.pdf'));pix=doc[0].get_pixmap(matrix=fitz.Matrix(2,2));pix.save(str(ROOT/(slug+('-poster' if live else '-DRAFT')+'.png')))
 manifest.append({'quiz':slug,'live':live,'url':('https://www.planetsorted.com/'+slug) if live else None,'proposed_path':None if live else '/'+slug})
combined.save()
(ROOT/'status.json').write_text(json.dumps(manifest,indent=2)+'\n')
(ROOT/'README.txt').write_text('SOR7ED quiz poster pack\n\nFive A4 vector PDFs plus high-resolution PNGs, using the original SOR7ED logo. QR codes encode their matching website URL and are scan-tested.\n\nHidden Strength Test is another address for Hidden Strength, not a separate assessment. Self-Perception Gap and Money Reset store answers only in browser storage and have Clear controls; Brain Type and Hidden Strength keep answers only in page memory. None are diagnostic tests.\n\nEditable generator: create_posters.py. Requires reportlab, pymupdf and Pillow. Open-license Anton/Roboto fonts and their licences are included.\n')

with zipfile.ZipFile(ROOT/'SOR7ED-poster-pack.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in ROOT.rglob('*'):
  if p.is_file() and p.suffix != '.zip':z.write(p,p.relative_to(ROOT))
print('Created five matching A4/PNG posters and complete download pack.')
